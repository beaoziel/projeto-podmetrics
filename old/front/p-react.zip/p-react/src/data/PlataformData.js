import Apple from '../assets/apple.png'
import Spotify from '../assets/spotify.png'
import Deezer from '../assets/deezer.png'
import Google from '../assets/google.png'

export const plataforms = [
    { image: (Apple),
    name: "Spotify"
    },
  
    { image: (Spotify),
    name: "Apple"
    },

    { image: (Deezer),
        name: "Deezer"
        },
    
    { image: (Google),
        name: "Google"
        },
   
];

